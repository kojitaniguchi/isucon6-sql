-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: isutar
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `star`
--

DROP TABLE IF EXISTS `star`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `star` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(191) COLLATE utf8mb4_bin NOT NULL,
  `user_name` varchar(191) COLLATE utf8mb4_bin NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `star`
--

LOCK TABLES `star` WRITE;
/*!40000 ALTER TABLE `star` DISABLE KEYS */;
INSERT INTO `star` VALUES (1,'Unicode一覧 D000-DFFF','ktat','2017-10-14 17:41:59'),(2,'湯築城','ktat','2017-10-14 17:42:00'),(3,'フェルミ国立加速器研究所','ktat','2017-10-14 17:42:00'),(4,'切込焼','ktat','2017-10-14 17:42:00'),(5,'ビザンティン','ktat','2017-10-14 17:42:00'),(6,'ルアンパバーン郡','ktat','2017-10-14 17:42:01'),(7,'キハ11形気動車','ktat','2017-10-14 17:42:01'),(8,'378年','ktat','2017-10-14 17:42:01'),(9,'島根県道249号八重垣神社八雲線','ktat','2017-10-14 17:42:01'),(10,'357年','ktat','2017-10-14 17:42:01'),(11,'イギリス政府','tmaesaka','2017-10-14 17:42:11'),(12,'イギリス政府','yanmar','2017-10-14 17:42:12'),(13,'771年','yanmar','2017-10-14 17:42:13'),(14,'ダブルリード','yanmar','2017-10-14 17:42:16'),(15,'輪状甲状筋','miki','2017-10-14 17:42:17'),(16,'平尾山','yanmar','2017-10-14 17:42:17'),(17,'Unicode一覧 D000-DFFF','yanmar','2017-10-14 17:42:19'),(18,'北消防署','miki','2017-10-14 17:42:19'),(19,'湯築城','yanmar','2017-10-14 17:42:21'),(20,'内田修平','miki','2017-10-14 17:42:21'),(21,'フェルミ国立加速器研究所','yanmar','2017-10-14 17:42:22'),(22,'ウーズ','miki','2017-10-14 17:42:23'),(23,'切込焼','yanmar','2017-10-14 17:42:24'),(24,'イギリス政府','miki','2017-10-14 17:42:24'),(25,'ビザンティン','yanmar','2017-10-14 17:42:25'),(26,'771年','miki','2017-10-14 17:42:26'),(27,'ダブルリード','miki','2017-10-14 17:42:27'),(28,'ルアンパバーン郡','yanmar','2017-10-14 17:42:27'),(29,'平尾山','miki','2017-10-14 17:42:28'),(30,'Unicode一覧 D000-DFFF','miki','2017-10-14 17:42:31'),(31,'エリック・バルフォー','myfinder','2017-10-14 17:42:38'),(32,'南蟹谷村','myfinder','2017-10-14 17:42:40'),(33,'エリック・バルフォー','unlearned','2017-10-14 17:42:41'),(34,'菅山かおる','myfinder','2017-10-14 17:42:41'),(35,'南蟹谷村','unlearned','2017-10-14 17:42:43'),(36,'巨大基数','myfinder','2017-10-14 17:42:44'),(37,'菅山かおる','unlearned','2017-10-14 17:42:45'),(38,'巨大基数','unlearned','2017-10-14 17:42:47'),(39,'河出書房新社','unlearned','2017-10-14 17:42:48'),(40,'輪状甲状筋','unlearned','2017-10-14 17:42:50'),(41,'札幌市交通局250形電車','shot','2017-10-14 17:42:51'),(42,'北消防署','unlearned','2017-10-14 17:42:51'),(43,'CCE','shot','2017-10-14 17:42:52'),(44,'内田修平','unlearned','2017-10-14 17:42:52'),(45,'八田小学校','shot','2017-10-14 17:42:54'),(46,'ウーズ','unlearned','2017-10-14 17:42:54'),(47,'オンテナ','shot','2017-10-14 17:42:55'),(48,'イギリス政府','unlearned','2017-10-14 17:42:55'),(49,'トイズ','shot','2017-10-14 17:42:56'),(50,'エリック・バルフォー','shot','2017-10-14 17:42:57'),(51,'南蟹谷村','shot','2017-10-14 17:42:58'),(52,'菅山かおる','shot','2017-10-14 17:43:00'),(53,'巨大基数','shot','2017-10-14 17:43:01'),(54,'河出書房新社','shot','2017-10-14 17:43:02');
/*!40000 ALTER TABLE `star` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-14 19:47:59
